package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.stockspring.dao.StockExchangeDao;
import com.example.stockspring.model.StockExchange;

@Service
public class StockExchangeServiceImpl implements StockExchangeService{

	@Autowired
	StockExchangeDao stockdao;
	@Override
	public StockExchange insertStock(StockExchange stock) {
		// TODO Auto-generated method stub
		 try {
			 stockdao.save(stock);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
	
	}

	@Override
	public List<StockExchange> getStockList() throws SQLException, Exception {
	 
		return stockdao.findAll();
	}

}
