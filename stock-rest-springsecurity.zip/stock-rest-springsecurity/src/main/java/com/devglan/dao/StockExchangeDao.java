package com.devglan.dao;
import java.sql.SQLException;
import java.util.List;


import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.devglan.model.*;

public interface StockExchangeDao extends JpaRepository<StockExchange, Integer>{
	
	

}

